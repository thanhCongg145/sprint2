
package minnumbergui;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MinNumberGUI {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Tìm Số Nhỏ Nhất");
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(4, 2));

        JLabel label1 = new JLabel("Nhập số thứ nhất:");
        JTextField text1 = new JTextField();
        JLabel label2 = new JLabel("Nhập số thứ hai:");
        JTextField text2 = new JTextField();
        JButton findMinButton = new JButton("Tìm số nhỏ nhất");
        JLabel resultLabel = new JLabel("Kết quả:");

        findMinButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    double num1 = Double.parseDouble(text1.getText());
                    double num2 = Double.parseDouble(text2.getText());
                    double min = Math.min(num1, num2);
                    resultLabel.setText("Số nhỏ nhất: " + min);
                } catch (NumberFormatException ex) {
                    resultLabel.setText("Vui lòng nhập số hợp lệ!");
                }
            }
        });

        frame.add(label1);
        frame.add(text1);
        frame.add(label2);
        frame.add(text2);
        frame.add(findMinButton);
        frame.add(resultLabel);

        frame.setVisible(true);
    }
}


